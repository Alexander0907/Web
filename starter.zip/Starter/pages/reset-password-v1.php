<?php
// Include config file
require_once "../layouts/config.php";

// Define variables and initialize with empty values
$useremail = $username =  $password = $confirm_password = "";
$useremail_err = $username_err = $password_err = $confirm_password_err = "";

// Processing form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Validate useremail
    if (empty(trim($_POST["useremail"]))) {
        $useremail_err = "Please enter useremail.";
    } elseif (!filter_var($_POST["useremail"], FILTER_VALIDATE_EMAIL)) {
        $useremail_err = "Invalid email format";
    } else {
        // Prepare a select statement
        $sql = "SELECT id FROM users WHERE useremail = ?";

        if ($stmt = mysqli_prepare($link, $sql)) {
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_useremail);

            // Set parameters
            $param_useremail = trim($_POST["useremail"]);

            // Attempt to execute the prepared statement
            if (mysqli_stmt_execute($stmt)) {
                /* store result */
                mysqli_stmt_store_result($stmt);

                if (mysqli_stmt_num_rows($stmt) == 1) {
                    
                    $useremail = trim($_POST["useremail"]);
                } else {
                    $useremail_err = "Useremail something went wrong.";
                }
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
            
        }
    }

    

    // Validate password
    $password = trim($_POST["password"]);
    if (empty($password)) {
        $password_err = "Please enter a password.";
    } elseif (!preg_match('/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$/', $password)) {
        $password_err = "Password must contain at least one digit, one lowercase letter, and one uppercase letter.";
    } else {
        $password = trim($_POST["password"]);
    }


    //Validate confirm password

    $password = trim($_POST["password"]);
    if (empty($password)) {
        $confirm_password_err = "Please enter a Confirm password.";
    } elseif (!preg_match('/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$/', $password)) {
        $confirm_password_err = "Password must contain at least one digit, one lowercase letter, and one uppercase letter.";
    } else {
        $confirm_password = trim($_POST["confirm_password"]);
        if (empty($password_err) && ($password != $confirm_password)) {
            $confirm_password_err = "Password did not match.";
        }
    }
    

    // Check input errors before inserting in database
    if (empty($useremail_err) && empty($password_err) && empty($confirm_password_err)) {

        // Prepare an insert statement
        //$sql = "INSERT INTO user (useremail, username, password ,token) VALUES (?, ?, ?, ?)";
        $sql ="UPDATE users SET password = ? WHERE useremail = '$useremail'";

        if ($stmt = mysqli_prepare($link, $sql)) {
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s",  $param_password, );

            // Set parameters
            $param_useremail = $useremail;
            //$param_username = $username;
            $param_password = password_hash($password, PASSWORD_DEFAULT); // Creates a password hash
            //$param_token = bin2hex(random_bytes(50));
            

            // Attempt to execute the prepared statement
            if (mysqli_stmt_execute($stmt)) {
                
                // Redirect to index page
                header("location: ../pages/login-v1.php");
            } else {
                echo "Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }

    // Close connection
    mysqli_close($link);
}

?>
<?php include '../layouts/main.php'; ?>
<!-- [Head] start -->

<head>
  <?php includeFileWithVariables('../layouts/head-page-meta.php', array('title' => 'Reset Passwor')); ?>
  <?php include '../layouts/head-css.php'; ?>
</head>
<!-- [Head] end -->
<!-- [Body] Start -->
<body >
  <?php include '../layouts/loader.php'; ?>
  <div class="auth-main v1">
    <div class="auth-wrapper">
      <div class="auth-form">
        <div class="card my-5">
          <div class="card-body">
            <div class="text-center">
              <img src="../assets/images/authentication/img-auth-reset-password.png" alt="images" class="img-fluid mb-3">
              <h4 class="f-w-500 mb-1">Reset password</h4>
              <p class="mb-3">Back to <a href="../pages/login-v1.php" class="link-primary ms-1">Log in</a></p>
            </div>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                    <div class="mb-3 <?= !empty($useremail_err) ? 'has-error' : ''; ?>">
                        <label class="form-label">Useremail</label>
                        <input type="email" class="form-control" name="useremail"
                             autocomplete="email" autofocus id="email"
                            placeholder="Email">
                            <span class="text-danger"><?php echo $useremail_err; ?></span>
                    </div>
                    <div class="mb-3 <?= !empty($password_err) ? 'has-error' : ''; ?>">
                        <label class="form-label">Password</label>
                        <input type="password" class="form-control" name="password"
                             autocomplete="new-password" id="floatingInput" placeholder="Password">
                            <span class="text-danger"><?php echo $password_err; ?></span>
                    </div>
                    <div class="mb-3 <?= !empty($confirm_password_err) ? 'has-error' : ''; ?>">
                        <label class="form-label">Confirm Password</label>
                        <input type="password" class="form-control" name="confirm_password" 
                            autocomplete="new-password" id="floatingInput1" placeholder="Confirm Password">
                            <span class="text-danger"><?php echo $confirm_password_err; ?></span>
                    </div>
                    <div class="d-grid mt-4">
                        <button type="submit" class="btn btn-primary">Reset Password</button>
                    </div>
                </form>
             <div class="saprator my-3">
              <span>Or continue with</span>
            </div>
            <div class="text-center">
              <ul class="list-inline mx-auto mt-3 mb-0">
                <li class="list-inline-item">
                  <a href="https://www.facebook.com/" class="avtar avtar-s rounded-circle bg-facebook" target="_blank">
                    <i class="fab fa-facebook-f text-white"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a href="https://twitter.com/" class="avtar avtar-s rounded-circle bg-twitter" target="_blank">
                    <i class="fab fa-twitter text-white"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a href="https://myaccount.google.com/" class="avtar avtar-s rounded-circle bg-googleplus" target="_blank">
                    <i class="fab fa-google text-white"></i>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <?php include '../layouts/auth-footer-block.php'; ?>
    </div>
  </div>
  <!-- [ Main Content ] end -->
  <?php include '../layouts/footer-js.php'; ?> <?php include '../layouts/customizer.php'; ?>
</body>
<!-- [Body] end -->

</html>