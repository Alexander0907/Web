<?php
// Initialize the session
session_start();

// Check if the user is already logged in, if yes then redirect him to index page
if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) {
    header("location: ../dashboard/index.php");
    exit;
}
// Include config file
require_once "../layouts/config.php";

// Define variables and initialize with empty values
$useremail = $password = "";
$useremail_err = $password_err = "";

// Processing form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Check if useremail is empty
    if (empty(trim($_POST["useremail"]))) {
        $useremail_err = "Please enter useremail.";
    } else {
        $useremail = trim($_POST["useremail"]);
    }

    // Check if password is empty
    if (empty(trim($_POST["password"]))) {
        $password_err = "Please enter your password.";
    } else {
        $password = trim($_POST["password"]);
    }

    // Validate credentials
    if (empty($useremail_err) && empty($password_err)) {
        // Prepare a select statement
        $sql = "SELECT id, useremail, password FROM users WHERE useremail = ?";

        if ($stmt = mysqli_prepare($link, $sql)) {
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_useremail);

            // Set parameters
            $param_useremail = $useremail;

            // Attempt to execute the prepared statement
            if (mysqli_stmt_execute($stmt)) {
                // Store result
                mysqli_stmt_store_result($stmt);

                // Check if useremail exists, if yes then verify password
                if (mysqli_stmt_num_rows($stmt) == 1) {
                    // Bind result variables
                    mysqli_stmt_bind_result($stmt, $id, $useremail, $hashed_password);
                    if (mysqli_stmt_fetch($stmt)) {
                        if (password_verify($password, $hashed_password)) {
                            // Password is correct, so start a new session
                            session_start();

                            // Store data in session variables
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id"] = $id;
                            $_SESSION["useremail"] = $useremail;
                            
                            // Redirect user to welcome page
                            header("location: ../dashboard/index.php");
                        } else {
                            // Display an error message if password is not valid
                            $password_err = "The password you entered was not valid.";
                        }
                    }
                } else {
                    // Display an error message if useremail doesn't exist
                    $useremail_err = "No account found with that email.";
                }
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }

    // Close connection
    mysqli_close($link);
}
?>
<?php include '../layouts/main.php'; ?>
<head>
  <?php includeFileWithVariables('../layouts/head-page-meta.php', array('title' => 'Login')); ?>
   <?php include '../layouts/head-css.php'; ?>
</head>
<!-- [Head] end -->
<!-- [Body] Start -->

<body >
  <?php include '../layouts/loader.php'; ?>
  <div class="auth-main v1">
    <div class="auth-wrapper">
      <div class="auth-form">
        <div class="card my-5">
          <div class="card-body">
            <div class="text-center">
              <img src="../assets/images/authentication/img-auth-login.png" alt="images" class="img-fluid mb-3">
              <h4 class="f-w-500 mb-1">Login with your email</h4>
              <p class="mb-3">Don't have an Account? <a href="../pages/register-v1.php" class="link-primary ms-1">Create Account</a></p>
              <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                  <div class="mb-3 <?php echo (!empty($useremail_err)) ? 'has-error' : ''; ?>" style="text-align : left">
                      <input type="email" class="form-control" name="useremail" value="admin@phoenixcoded.com" required autocomplete="email" autofocus id="floatingInput" placeholder="Email Address">
                      <span class="text-danger"><?php echo $useremail_err; ?></span>
                  </div>
                  <div class="mb-3 <?php echo (!empty($password_err)) ? 'has-error' : ''; ?>" style="text-align : left">
                      <input type="password" type="password" class="form-control" value="Admin123" name="password" required autocomplete="current-password" id="floatingInput1" placeholder="Password">
                      <span class="text-danger"><?php echo $password_err; ?></span>
                  </div>
                  <div class="d-flex mt-1 justify-content-between align-items-center">
                      <div class="form-check">
                          <input class="form-check-input input-primary" type="checkbox" id="remember">
                          <label class="form-check-label text-muted" for="remember">Remember me?</label>
                      </div>
                      <a href="../pages/forgot-password-v1.php">
                          <h6 class="f-w-400 mb-0">Forgot Password?</h6>
                      </a>
                  </div>
                  <div class="d-grid mt-4">
                      <button type="submit" class="btn btn-primary">Login</button>
                  </div>
              </form>
             <div class="saprator my-3">
              <span>Or continue with</span>
            </div>
            </div>
            <div class="text-center">
              <ul class="list-inline mx-auto mt-3 mb-0">
                <li class="list-inline-item">
                  <a href="https://www.facebook.com/" class="avtar avtar-s rounded-circle bg-facebook" target="_blank">
                    <i class="fab fa-facebook-f text-white"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a href="https://twitter.com/" class="avtar avtar-s rounded-circle bg-twitter" target="_blank">
                    <i class="fab fa-twitter text-white"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a href="https://myaccount.google.com/" class="avtar avtar-s rounded-circle bg-googleplus" target="_blank">
                    <i class="fab fa-google text-white"></i>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <?php include '../layouts/auth-footer-block.php'; ?>
    </div>
  </div>
  <!-- [ Main Content ] end -->
  <?php include '../layouts/footer-js.php'; ?> 
  <?php include '../layouts/customizer.php'; ?>
</body>
<!-- [Body] end -->

</html>