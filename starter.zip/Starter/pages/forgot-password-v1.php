<?php
// Include config file
require_once "../layouts/config.php";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . '../../vendor/phpmailer/src/Exception.php';
require_once __DIR__ . '../../vendor/phpmailer/src/PHPMailer.php';
require_once __DIR__ . '../../vendor/phpmailer/src/SMTP.php';

$useremail_err = $msg = "";

// passing true in constructor enables exceptions in PHPMailer
$mail = new PHPMailer(true);
$uri_path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri_segments = explode('/', $uri_path);
$actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]/$uri_segments[1]";
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $useremail = mysqli_real_escape_string($link, $_POST['useremail']);

    $sql = "SELECT * FROM users WHERE useremail = '$useremail'";
    $query = mysqli_query($link, $sql);
    $emailcount = mysqli_num_rows($query);

    if(empty(trim($_POST["useremail"]))) {
        $useremail_err = "Please enter useremail.";
    }elseif (!filter_var($_POST["useremail"], FILTER_VALIDATE_EMAIL)) {
        $useremail_err = "Invalid email format";
    }elseif ($emailcount) {
        $userdata = mysqli_fetch_array($query);
        $username = $userdata['username'];
        $token = $userdata['token'];

        $subject = "Password Reset";
        $body = "Hi, $username. Click here to reset your password: <br><a href=\"$actual_link/admin/pages/reset-password-v1.php?token=$token\">$actual_link/password_create_1.php.php?token=$token</a>";
        $sender_email = "From: $gmailid";

        try {
            // Server settings
            // $mail->SMTPDebug = SMTP::DEBUG_SERVER; // for detailed debug output
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            $mail->Username = $gmailid;
            $mail->Password = $gmailpassword;

            // Sender and recipient settings
            $mail->setFrom($gmailid, $gmailusername);
            $mail->addAddress($useremail, $username);
            $mail->addReplyTo($gmailid, $gmailusername); // to set the reply to

            // Setting the email content
            $mail->IsHTML(true);
            $mail->Subject = $subject;
            $mail->Body = $body;

            $mail->send();
            $msg = "We have emailed your password reset link!";
            // header("location:auth-login.php");
        } catch (Exception $e) {
            $useremail_err =  "Error in sending email. Mailer Error: {$mail->ErrorInfo}";
        }
    } else {
        $useremail_err = "No Email Found";
    }
}
?>
<?php include '../layouts/main.php'; ?>
<!-- [Head] start -->

<head>
  <?php includeFileWithVariables('../layouts/head-page-meta.php', array('title' => 'Forgot password')); ?> 
  <?php include '../layouts/head-css.php'; ?>
</head>
<!-- [Head] end -->
<!-- [Body] Start -->

<body >
  <?php include '../layouts/loader.php'; ?>
  <div class="auth-main v1">
    <div class="auth-wrapper">
      <div class="auth-form">
        <div class="card my-5">
          <div class="card-body">
            <div class="text-center">
              <img src="../assets/images/authentication/img-auth-fporgot-password.png" alt="images" class="img-fluid mb-3">
              <h4 class="f-w-500 mb-1">Forgot Password</h4>
              <p class="mb-3">Back to <a href="../pages/login-v1.php" class="link-primary ms-1">Log in</a></p>
            </div>
            <?php if ($msg) { ?>
                <div class="alert alert-success text-center mb-4 mt-4 pt-2" role="alert">
                        <?php echo $msg; ?>
                </div>
            <?php } ?>
            <form action="<?php echo htmlentities($_SERVER["PHP_SELF"]); ?>" method="post">
                <div class=" mb-3 <?= !empty($useremail_err) ? 'has-error' : ''; ?>">
                    <label class="form-label">Email Address</label>
                    <input type="email" class="form-control" name="useremail"
                          autocomplete="email" autofocus id="floatingInput"
                        placeholder="Email Address">
                        <span class="text-danger"><?php echo $useremail_err; ?></span>
                </div>
                <div class="d-grid mt-3">
                    <button type="submit" class="btn btn-primary">Send reset email</button>
                </div>
            </form>
          </div>
        </div>
      </div>
      <?php include '../layouts/auth-footer-block.php'; ?>
    </div>
  </div>
  <!-- [ Main Content ] end -->
  <?php include '../layouts/footer-js.php'; ?> <?php include '../layouts/customizer.php'; ?>
</body>
<!-- [Body] end -->

</html>