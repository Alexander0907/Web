<?php include '../layouts/main.php'; ?>
<!-- [Head] start -->

<head>
  <?php includeFileWithVariables('../layouts/head-page-meta.php', array('title' => 'Layout Extended')); ?> <?php include '../layouts/head-css.php'; ?>
</head>
<!-- [Head] end -->
<!-- [Body] Start -->

<body class="layout-extended" @@bodySetup>
  <?php include '../layouts/layout-extended.php'; ?>

  <div class="pc-tab-wrapper">
    <div class="pc-tabs">
      <div class="container">
        <ul class="nav pc-tabs nav-tabs" id="myTab" role="tablist">
          <li class="nav-item" role="presentation">
            <button
              class="nav-link active"
              id="pc-tab-1-tab"
              data-bs-toggle="tab"
              data-bs-target="#pc-tab-1-tab-pane"
              type="button"
              role="tab"
              aria-controls="pc-tab-1-tab-pane"
              aria-selected="true">Navigation</button>
          </li>
          <li class="nav-item" role="presentation">
            <button
              class="nav-link"
              id="pc-tab-2-tab"
              data-bs-toggle="tab"
              data-bs-target="#pc-tab-2-tab-pane"
              type="button"
              role="tab"
              aria-controls="pc-tab-2-tab-pane"
              aria-selected="false">Widget</button>
          </li>
          <li class="nav-item" role="presentation">
            <button
              class="nav-link"
              id="pc-tab-3-tab"
              data-bs-toggle="tab"
              data-bs-target="#pc-tab-3-tab-pane"
              type="button"
              role="tab"
              aria-controls="pc-tab-3-tab-pane"
              aria-selected="false">Application</button>
          </li>
          <li class="nav-item" role="presentation">
            <button
              class="nav-link"
              id="pc-tab-4-tab"
              data-bs-toggle="tab"
              data-bs-target="#pc-tab-4-tab-pane"
              type="button"
              role="tab"
              aria-controls="pc-tab-4-tab-pane"
              aria-selected="false">UI Components</button>
          </li>
        </ul>
      </div>
    </div>
    <div class="pc-tab-content">
      <div class="container">
        <div class="tab-content pc-tab-content" id="myTabContent">
          <div class="tab-pane fade show active" id="pc-tab-1-tab-pane" role="tabpanel" aria-labelledby="pc-tab-1-tab" tabindex="0">
            <?php include '../layouts/submenu-list.php'; ?>
          </div>
          <div class="tab-pane fade" id="pc-tab-2-tab-pane" role="tabpanel" aria-labelledby="pc-tab-2-tab" tabindex="0">
            <?php include '../layouts/submenu-list.php'; ?>
          </div>
          <div class="tab-pane fade" id="pc-tab-3-tab-pane" role="tabpanel" aria-labelledby="pc-tab-3-tab" tabindex="0">
            <?php include '../layouts/submenu-list.php'; ?>
          </div>
          <div class="tab-pane fade" id="pc-tab-4-tab-pane" role="tabpanel" aria-labelledby="pc-tab-4-tab" tabindex="0">
            <?php include '../layouts/submenu-list.php'; ?>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- [ Main Content ] start -->
  <div class="pc-container">
    <div class="pc-content">
      <?php includeFileWithVariables('../layouts/breadcrumb.php', array('title' => 'Layout', 'pagetitle' => 'Layout Extended')); ?>
      <!-- [ Main Content ] start -->
      <div class="row">
        <!-- [ sample-page ] start -->
        <div class="col-sm-12">
          <div class="card">
            <div class="card-header">
              <h5>Hello card</h5>
            </div>
            <div class="card-body">
              <p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna
                aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis
                aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat
                cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
              </p>
            </div>
          </div>
        </div>
        <!-- [ sample-page ] end -->
      </div>
      <!-- [ Main Content ] end -->
    </div>
  </div>
  <!-- [ Main Content ] end -->
  <?php include '../layouts/footer-block.php'; ?>
  <?php include '../layouts/footer-js.php'; ?>
  <?php include '../layouts/customizer.php'; ?>
  <script>
    change_box_container('true');
  </script>
</body>
<!-- [Body] end -->

</html>