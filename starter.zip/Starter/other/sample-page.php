<?php include '../layouts/main.php'; ?>
<!-- [Head] start -->

<head>
  <?php includeFileWithVariables('../layouts/head-page-meta.php', array('title' => 'Sample Page')); ?> <?php include '../layouts/head-css.php'; ?>
</head>
<!-- [Head] end -->
<!-- [Body] Start -->

<body >
  <?php include '../layouts/layout-vertical.php'; ?>

  <!-- [ Main Content ] start -->
  <div class="pc-container">
    <div class="pc-content">
      <?php includeFileWithVariables('../layouts/breadcrumb.php', array('title' => 'Other' , 'pagetitle' => 'Sample Page')); ?>

      <!-- [ Main Content ] start -->
      <div class="row">
        <!-- [ sample-page ] start -->
        <div class="col-sm-12">
          <div class="card">
            <div class="card-header">
              <h5>Hello card</h5>
            </div>
            <div class="card-body">
            </div>
          </div>
        </div>
        <!-- [ sample-page ] end -->
      </div>
      <!-- [ Main Content ] end -->
    </div>
  </div>
  <!-- [ Main Content ] end -->
  <?php include '../layouts/footer-block.php'; ?> <?php include '../layouts/footer-js.php'; ?>
  <?php include '../layouts/customizer.php'; ?>
</body>
<!-- [Body] end -->

</html>