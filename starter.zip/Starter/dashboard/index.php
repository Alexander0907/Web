<?php include '../layouts/session.php'; ?>
<?php include '../layouts/main.php'; ?>

  <head>
    <?php includeFileWithVariables('../layouts/head-page-meta.php', array('title' => 'Home')); ?>
    <!-- map-vector css -->
    <link rel="stylesheet" href="../assets/css/plugins/jsvectormap.min.css">
    <?php include '../layouts/head-css.php'; ?>
    
  </head>
  <!-- [Head] end -->
  <!-- [Body] Start -->

  <body >
    <?php include '../layouts/layout-vertical.php'; ?>

    <!-- [ Main Content ] start -->
    <div class="pc-container">
      <div class="pc-content">
        <?php includeFileWithVariables('../layouts/breadcrumb.php', array('pagetitle' => 'Home', 'title' => 'Dashboard')); ?>
        <!-- [ Main Content ] start -->
        
        <!-- [ Main Content ] end -->
      </div>
    </div>
    <!-- [ Main Content ] end -->
    <?php include '../layouts/footer-block.php'; ?>
    <?php include '../layouts/customizer.php'; ?>
    <!-- [Page Specific JS] start -->
    <!-- [Page Specific JS] end -->
    <?php include '../layouts/footer-js.php'; ?>
  </body>
  <!-- [Body] end -->
</html>
