<title><?= ($title) ? $title : '' ?> | Light Able Admin & Dashboard Template</title>
<!-- [Meta] -->
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta
  name="description"
  content="Light Able admin and dashboard template offer a variety of UI elements and pages, ensuring your admin panel is both fast and effective."
/>
<meta name="author" content="phoenixcoded" />

<!-- [Favicon] icon -->
<link rel="icon" href="../assets/images/favicon.svg" type="image/x-icon" />
