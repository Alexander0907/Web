
<?php include 'loader.php'; ?>
<?php include 'sidebar-detached.php'; ?>
<?php include 'topbar-detached.php'; ?>