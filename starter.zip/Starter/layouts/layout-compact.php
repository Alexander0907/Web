<?php include 'loader.php'; ?>
<?php include 'sidebar-compact.php'; ?>
<?php include 'topbar.php'; ?>
