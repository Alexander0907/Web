<div class="offcanvas-xl offcanvas-start component-offcanvas" tabindex="-1" id="offcanvas_component">
  <div class="offcanvas-header">
    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" data-bs-target="#offcanvas_component" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body p-0">
    <div class="card component-list-card position-xl-fixed">
      <div class="card-header">
        <div class="form-search">
          <i class="ph-duotone ph-magnifying-glass icon-search"></i>
          <input type="search" class="form-control" placeholder="Search Components " id="compo-menu-search" >
        </div>
      </div>
      <div class="card-body p-0">
        <ul class="list-group list-group-flush">
          <li class="list-group-item"><h5 class="mt-3">Basic Components</h5></li>
          <li><a href="#" class="list-group-item list-group-item-action">All</a></li>
          <li><a href="../elements/bc_alert.php" class="list-group-item list-group-item-action">Alert</a></li>
          <li><a href="../elements/bc_button.php" class="list-group-item list-group-item-action">Button</a></li>
          <li><a href="../elements/bc_badges.php" class="list-group-item list-group-item-action">Badges</a></li>
          <li><a href="../elements/bc_breadcrumb.php" class="list-group-item list-group-item-action">Breadcrumb</a></li>
          <li><a href="../elements/bc_card.php" class="list-group-item list-group-item-action">Cards</a></li>
          <li><a href="../elements/bc_color.php" class="list-group-item list-group-item-action">Color</a></li>
          <li><a href="../elements/bc_collapse.php" class="list-group-item list-group-item-action">Collapse</a></li>
          <li><a href="../elements/bc_carousel.php" class="list-group-item list-group-item-action">Carousel</a></li>
          <li><a href="../elements/bc_dropdowns.php" class="list-group-item list-group-item-action">Dropdowns</a></li>
          <li><a href="../elements/bc_offcanvas.php" class="list-group-item list-group-item-action">Offcanvas</a></li>
          <li><a href="../elements/bc_pagination.php" class="list-group-item list-group-item-action">Pagination</a></li>
          <li><a href="../elements/bc_progress.php" class="list-group-item list-group-item-action">Progress</a></li>
          <li><a href="../elements/bc_list-group.php" class="list-group-item list-group-item-action">List group</a></li>
          <li><a href="../elements/bc_modal.php" class="list-group-item list-group-item-action">Modal</a></li>
          <li><a href="../elements/bc_spinner.php" class="list-group-item list-group-item-action">Spinner</a></li>
          <li><a href="../elements/bc_tabs.php" class="list-group-item list-group-item-action">Tabs & pills</a></li>
          <li><a href="../elements/bc_tooltip-popover.php" class="list-group-item list-group-item-action">Tooltip</a></li>
          <li><a href="../elements/bc_toasts.php" class="list-group-item list-group-item-action">Toasts</a></li>
          <li><a href="../elements/bc_typography.php" class="list-group-item list-group-item-action">Typography</a></li>
          <li><a href="../elements/bc_extra.php" class="list-group-item list-group-item-action">Other</a></li>
          <li class="list-group-item"><h5 class="mt-3">Advance Components</h5></li>
          <li><a href="../elements/ac_alert.php" class="list-group-item list-group-item-action">Sweet alert</a></li>
          <li><a href="../elements/ac_datepicker-component.php" class="list-group-item list-group-item-action">Datepicker</a></li>
          <li><a href="../elements/ac_lightbox.php" class="list-group-item list-group-item-action">Lightbox</a></li>
          <li><a href="../elements/ac_modal.php" class="list-group-item list-group-item-action">Modal</a></li>
          <li><a href="../elements/ac_notification.php" class="list-group-item list-group-item-action">Notification</a></li>
          <li><a href="../elements/ac_rangeslider.php" class="list-group-item list-group-item-action">Rangeslider</a></li>
          <li><a href="../elements/ac_slider.php" class="list-group-item list-group-item-action">Slider</a></li>
          <li><a href="../elements/ac_syntax_highlighter.php" class="list-group-item list-group-item-action">Syntax Highlighter</a></li>
          <li><a href="../elements/ac_tour.php" class="list-group-item list-group-item-action">Tour</a></li>
          <li><a href="../elements/ac_treeview.php" class="list-group-item list-group-item-action">Tree view</a></li>
        </ul>
      </div>
    </div>
  </div>
</div>
