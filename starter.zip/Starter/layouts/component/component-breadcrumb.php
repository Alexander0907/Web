<div class="col-md-10 col-xxl-9 mb-4">
  <a href="#" class="d-inline-flex align-items-center d-xl-none btn btn-dark mb-3" data-bs-toggle="offcanvas" data-bs-target="#offcanvas_component"
    ><i class="ti ti-menu-2 me-2"></i> Explore Components
  </a>
  <h2><?= ($title) ? $title : '' ?></h2>
  <p class="text-muted"><?= ($text) ? $text : '' ?></p>
  <div>
    <a class="btn btn-sm btn-light-dark rounded-pill px-2" role="button" target="_blank" href="<?= ($link) ? $link : '' ?>">
      <i class="ti ti-external-link me-1"></i>
      Reference
    </a>
  </div>
</div>
