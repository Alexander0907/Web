<!-- Required Js -->
<script src="../assets/js/plugins/popper.min.js"></script>
<script src="../assets/js/plugins/simplebar.min.js"></script>
<script src="../assets/js/plugins/bootstrap.min.js"></script>
<script src="../assets/js/plugins/i18next.min.js"></script>
<script src="../assets/js/plugins/i18nextHttpBackend.min.js"></script>
<script src="../assets/js/icon/custom-font.js"></script>
<script src="../assets/js/script.js"></script>
<script src="../assets/js/theme.js"></script>
<script src="../assets/js/multi-lang.js"></script>
<script src="../assets/js/plugins/feather.min.js"></script>

<script>
    const caption_show = 'true'; // [ false , true ]
    const dark_navbar = 'false'; // [ false , true ]
    const preset_theme = 'preset-1'; // [ preset-1 to preset-10 ]
    const dark_layout = 'false'; // [ false , true , default ]
    const rtl_layout = 'false'; // [ false , true ]
    const box_container = 'false'; // [ false , true ]
    const version = 'v1.0';

    if (rtl_layout == "true") {
        var rtltemp = "rtl"
    } else {
        var rtltemp = "ltr"
    }

    if (dark_layout == 'true') {
        var darklayouttemp = "dark"
    } else {
        var darklayouttemp = "light"
    }
    if (dark_navbar == 'true') {
        var darknavbartemp = "dark"
    } else {
        var darknavbartemp = "light"
    }

    pc_caption_show = caption_show,
    pc_preset_theme = preset_theme,
    pc_dark_navbar = dark_navbar,
    pc_dark_layout = dark_layout,
    pc_rtl_layout = rtl_layout,
    pc_box_container = box_container,
    pc_theme_version = version,
    bodySetup = 'data-pc-preset="' + preset_theme + '" data-pc-sidebar-theme="' + darknavbartemp + '" data-pc-sidebar-caption="' + caption_show + '" data-pc-direction="' + rtltemp + '" data-pc-theme="' + darklayouttemp + '"';

    if(pc_dark_layout == 'default') {
        if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
            dark_layout = 'true';
        } else {
            dark_layout = 'false';
        }
        layout_change_default();
        if (dark_layout == 'true') {
            layout_change('dark');
        } else {
            layout_change('light');
        }
    }
    
    if (pc_dark_layout != 'default') {
        if (pc_dark_layout == 'true') {
            layout_change('dark');
        }
        if (pc_dark_layout == 'false') {
            layout_change('light');
        }
    }

    if (pc_dark_navbar == 'true') {
        layout_sidebar_change('dark');
    }
    if (pc_dark_navbar == 'false') {
        layout_sidebar_change('light');
    }
    if (pc_box_container == 'true') {
        change_box_container('true');
    }
    if (pc_box_container == 'false') {
        change_box_container('false');
    }
    if (pc_caption_show == 'true') {
        layout_caption_change('true');
    }
    if (pc_caption_show == 'false') {
        layout_caption_change('false');
    }
    if (pc_rtl_layout == 'true') {
        layout_rtl_change('true');
    }
    if (pc_rtl_layout == 'false') {
        layout_rtl_change('false');
    }
    if (pc_preset_theme != "") {
        preset_change(pc_preset_theme);
    }
</script>